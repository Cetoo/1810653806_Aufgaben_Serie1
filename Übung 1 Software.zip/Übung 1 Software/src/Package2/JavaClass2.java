package Package2;

public class JavaClass2
{

    public static void main(String[] args)
    {
        System.out.println("FH Kufstein Tirol");



    }




}
